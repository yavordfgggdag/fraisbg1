// Общи функции за прогрес барове
function updateProgress(id, value) {
  const fill = document.getElementById(id);
  if (fill) fill.style.width = value + '%';
}

// Index: енергия, кислород, гориво
let energy = 75;
let oxygen = 90;
let fuel = 80;

function addEnergy(amount) { energy = Math.min(100, energy + amount); updateProgress('energy-bar', energy); updateText('energy-value', energy+'%'); }
function addOxygen(amount) { oxygen = Math.min(100, oxygen + amount); updateProgress('oxygen-bar', oxygen); updateText('oxygen-value', oxygen+'%'); }
function addFuel(amount) { fuel = Math.min(100, fuel + amount); updateProgress('fuel-bar', fuel); updateText('fuel-value', fuel+'%'); }

function updateText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

// Diagnostics: логове и аларми
const logs = document.getElementById('logs');
const alerts = document.getElementById('alerts');

function addLog(message) {
  if (!logs) return;
  const li = document.createElement('li');
  li.textContent = message;
  logs.prepend(li);
  if (logs.children.length > 20) logs.removeChild(logs.lastChild);
}

function addAlert(message) {
  if (!alerts) return;
  const li = document.createElement('li');
  li.textContent = message;
  alerts.prepend(li);
  if (alerts.children.length > 10) alerts.removeChild(alerts.lastChild);
}

// Heartbeat / стабилност
const heartbeatCanvas = document.getElementById('heartbeat');
let hbCtx, hbTime = 0;
if (heartbeatCanvas) {
  hbCtx = heartbeatCanvas.getContext('2d');
  function drawHeartbeat() {
    hbCtx.clearRect(0,0,heartbeatCanvas.width,heartbeatCanvas.height);
    hbCtx.beginPath();
    for(let x=0;x<heartbeatCanvas.width;x++){
      let y = 40 + 30*Math.sin((x+hbTime)/15);
      if(x===0) hbCtx.moveTo(x,y); else hbCtx.lineTo(x,y);
    }
    hbCtx.strokeStyle = 'lime';
    hbCtx.lineWidth = 2;
    hbCtx.stroke();
    hbTime++;
    requestAnimationFrame(drawHeartbeat);
  }
  drawHeartbeat();
}

// Crew: бутони "Виж повече"
document.querySelectorAll('.crew-item .btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const link = btn.getAttribute('data-link');
    if(link) window.location.href = link;
  });
});

// Status: скорост и промяна на потребленията
let speed = 0;
function setSpeed(val){
  speed = val;
  // ако имаме progress барове за потребление
  if(document.getElementById('energy-bar')) updateProgress('energy-bar', Math.max(0, energy - speed/2));
  if(document.getElementById('fuel-bar')) updateProgress('fuel-bar', Math.max(0, fuel - speed/3));
}

// Функция за начална инициализация на всички страници
function init() {
  // Diagnostics dummy данни
  addLog("Система стартира успешно");
  addLog("Проверка на сензори...");
  addAlert("Няма аларми");
  // Index dummy прогреси
  updateProgress('energy-bar', energy);
  updateProgress('fuel-bar', fuel);
  updateProgress('oxygen-bar', oxygen);
}

document.addEventListener('DOMContentLoaded', init);
