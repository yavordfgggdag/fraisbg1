(() => {

  const logBox = document.getElementById('log');
  const missionStatus = document.getElementById('mission-status');

  const barEnergy = document.getElementById('bar-energy');
  const barFuel = document.getElementById('bar-fuel');
  const barOxygen = document.getElementById('bar-oxygen');

  const redAlert = document.getElementById('red-alert');

  const btnStart = document.getElementById('btn-start');
  const btnStop = document.getElementById('btn-stop');
  const btnBoost = document.getElementById('btn-boost');
  const btnStandard = document.getElementById('btn-standard'); // новият бутон
  const btnEmergency = document.getElementById('btn-emergency');

  const btnAddEnergy = document.getElementById('add-energy');
  const btnAddFuel = document.getElementById('add-fuel');
  const btnAddOxygen = document.getElementById('add-oxygen');

  const energyCanvas = document.getElementById('energyChart');
  const ctx = energyCanvas.getContext('2d');

  const state = {
    energy: 78,
    fuel: 67,
    oxygen: 92,
    engine: false,
    boost: false,
    paused: true
  };

  const historyLength = 240;
  const history = Array(historyLength).fill(state.energy);

  const clamp = v => Math.max(0, Math.min(100, v));

  function log(text){
    const d = document.createElement('div');
    d.textContent = `> ${text}`;
    logBox.appendChild(d);
    logBox.scrollTop = logBox.scrollHeight;
  }

  function updateBars(){
    barEnergy.style.width = state.energy + '%';
    barFuel.style.width = state.fuel + '%';
    barOxygen.style.width = state.oxygen + '%';
  }

  function startEngine(){
    state.engine = true;
    state.paused = false;
    missionStatus.textContent = 'В ход';
    log('🚀 Двигател стартиран');
  }

  function stopEngine(){
    state.engine = false;
    state.boost = false;
    state.paused = true;
    missionStatus.textContent = 'Спряна';
    log('■ Двигател спрян');
  }

  function boost(){
    if(!state.engine){ log('⚠ Няма стартиран двигател'); return; }
    state.boost = true;
    log('⚡ Boost активиран');
    document.body.classList.add('boosting');
  }

  function standard(){
    if(!state.engine){ log('⚠ Няма стартиран двигател'); return; }
    state.boost = false;
    log('✅ Връщане към стандартен режим');
    document.body.classList.remove('boosting');
  }

  function emergency(){
    state.engine=false;
    state.paused=true;
    missionStatus.textContent='Авария';
    redAlert.classList.add('red-flash');
    log('🛑 АВАРИЙНО СПИРАНЕ');
    setTimeout(()=>redAlert.classList.remove('red-flash'),3000);
  }

  btnStart.onclick=startEngine;
  btnStop.onclick=stopEngine;
  btnBoost.onclick=boost;
  btnStandard.onclick=standard; // логика за новия бутон
  btnEmergency.onclick=emergency;

  btnAddEnergy.onclick=()=>{state.energy=clamp(state.energy+10);log('➕ Енергия');};
  btnAddFuel.onclick=()=>{state.fuel=clamp(state.fuel+10);log('➕ Гориво');};
  btnAddOxygen.onclick=()=>{state.oxygen=clamp(state.oxygen+10);log('➕ Кислород');};

  function update(){
    if(state.paused) return;

    const consumptionRate = 0.05; // бавно падаща енергия
    state.energy = clamp(state.energy - consumptionRate);
    state.fuel   = clamp(state.fuel - 0.06);
    state.oxygen = clamp(state.oxygen - 0.01);

    updateBars();
  }

  function drawChart(){
    ctx.clearRect(0,0,energyCanvas.width,energyCanvas.height);
    ctx.beginPath();

    const scrollMultiplier = state.boost ? 3 : 1; // ускоряване на линията
    for(let step=0; step<scrollMultiplier; step++){
      history.push(state.energy);
      history.shift();
    }

    history.forEach((v,i)=>{
      const x = i / history.length * energyCanvas.width;
      const y = energyCanvas.height - (v/100) * energyCanvas.height;
      i ? ctx.lineTo(x,y) : ctx.moveTo(x,y);
    });

    ctx.strokeStyle='#d28cf7';
    ctx.lineWidth=2;
    ctx.stroke();
  }

  function loop(){
    update();
    drawChart();
    requestAnimationFrame(loop);
  }

  log('Системите са онлайн');
  updateBars();
  loop();

})();
