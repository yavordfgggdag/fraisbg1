const crewData = [
  { name: "Алекс Иванов", role: "Капитан / Главнокомандващ", status: "online", location: "Command Deck", hours: 1280, photo: "https://i.postimg.cc/vB1yNQX9/captain-ivan.png", bio: "Ветеран с 5 орбитални мисии и 3 скачвания с Dragon." },
  { name: "Даниела Петрова", role: "Навигатор", status: "online", location: "Nav Station", hours: 980, photo: "https://i.postimg.cc/nzsxPHTB/navigator.png", bio: "Специалист по траектории и deep space маршрути." },
  { name: "Мирослав Георгиев", role: "Главен инженер", status: "online", location: "Engineering", hours: 1100, photo: "https://i.postimg.cc/9M42nW1R/enginer.png", bio: "Отговаря за системи на борда и извънбордни операции." },
  { name: "Елена Ангелова", role: "Главен медик", status: "alert", location: "Med Bay", hours: 720, photo: "https://i.postimg.cc/tgvyk1dh/medic-angelova.png", bio: "Медицинско осигуряване и биометричен мониторинг." },
  { name: "Николай Стоянов", role: "Тактически офицер", status: "online", location: "Operations", hours: 860, photo: "https://i.postimg.cc/zf257LwT/tacticofficer.png", bio: "Отговаря за сигурността и тактическите протоколи." },
  { name: "Виктория Миланова", role: "Научен офицер", status: "online", location: "Lab", hours: 640, photo: "https://i.postimg.cc/8CzNLdvp/specialist.png", bio: "Ръководи експериментите и научните пейлоуди." },
  { name: "Ивайло Кръстев", role: "Комуникации и криптография", status: "online", location: "Comms", hours: 790, photo: "https://i.postimg.cc/GpgrKBP9/crypto.png", bio: "Сигурни канали, декодиране и квантови връзки." },
  { name: "Радослав Пеев", role: "Пилот", status: "online", location: "Cockpit", hours: 910, photo: "https://i.postimg.cc/6Qbwc7Vq/pilot.png", bio: "Сертифициран пилот за Falcon/Dragon, специализиран в прецизни маневри." },
  { name: "Калоян Марков", role: "Специалист по машинни системи", status: "offline", location: "Hangar", hours: 540, photo: "https://i.postimg.cc/R0p9d313/seniorofficer.png", bio: "Инженер по роботика и механични системи." },
  { name: "Стефания Костова", role: "Офицер по сигурността", status: "alert", location: "Security", hours: 600, photo: "https://i.postimg.cc/7LtD9C15/security.png", bio: "Командва тактическия отговор и физическата сигурност." }
];

document.addEventListener("DOMContentLoaded", () => {
  hydrateCrewCards();
  initFilters();
  initModal();
  initTilt();
  initReveal();
  initShortcuts();
});

// Попълваме картите със снимки, статус и бърз бутон
function hydrateCrewCards(){
  const cards = document.querySelectorAll(".crew-item");
  cards.forEach(card => {
    const name = card.querySelector("h4")?.innerText.trim();
    const entry = crewData.find(c => c.name === name);
    if(!entry) return;
    // снимка
    const img = card.querySelector("img.crew-photo");
    if(img) img.src = entry.photo;
    // статус бейдж
    let badge = card.querySelector(".status-badge");
    if(!badge){
      badge = document.createElement("span");
      badge.className = "status-badge";
      card.appendChild(badge);
    }
    badge.textContent = entry.status === "online" ? "Online" : entry.status === "alert" ? "Alert" : "Offline";
    badge.classList.remove("status-online","status-alert","status-offline");
    badge.classList.add(`status-${entry.status}`);
    // данни за филтриране
    card.dataset.role = entry.role;
    card.dataset.status = entry.status;
    // reveal & tilt
    card.classList.add("reveal","tilt");
    // бутон бърз преглед
    if(!card.querySelector(".btn-quick")){
      const quick = document.createElement("button");
      quick.className = "btn-ghost btn-quick";
      quick.textContent = "Бърз преглед";
      quick.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        openModal(entry);
      });
      card.appendChild(quick);
    }
    // клик върху снимката също отваря модала
    img?.addEventListener("click", (e) => { e.preventDefault(); openModal(entry); });
  });
}

// Филтри и търсене
function initFilters(){
  const search = document.getElementById("crewSearch");
  const filter = document.getElementById("roleFilter");
  const reset = document.getElementById("resetFilters");
  const cards = document.querySelectorAll(".crew-item");

  const applyFilters = () => {
    const term = (search.value || "").toLowerCase();
    const roleVal = filter.value;
    cards.forEach(card => {
      const name = card.querySelector("h4")?.innerText.toLowerCase() || "";
      const role = (card.dataset.role || "").toLowerCase();
      const matchTerm = name.includes(term) || role.includes(term);
      const matchRole = !roleVal || role === roleVal.toLowerCase();
      const visible = matchTerm && matchRole;
      card.style.display = visible ? "" : "none";
    });
  };
  search?.addEventListener("input", applyFilters);
  filter?.addEventListener("change", applyFilters);
  reset?.addEventListener("click", () => { search.value=""; filter.value=""; applyFilters(); });
  applyFilters();
}

// Quick View модал
let modalBackdrop, modalPhoto, modalName, modalRole, modalBio, modalStatus, modalLocation, modalHours;
function initModal(){
  modalBackdrop = document.getElementById("crewModal");
  modalPhoto = document.getElementById("modalPhoto");
  modalName = document.getElementById("modalName");
  modalRole = document.getElementById("modalRole");
  modalBio = document.getElementById("modalBio");
  modalStatus = document.getElementById("modalStatus");
  modalLocation = document.getElementById("modalLocation");
  modalHours = document.getElementById("modalHours");
  document.getElementById("closeModal")?.addEventListener("click", closeModal);
  modalBackdrop?.addEventListener("click", (e) => { if(e.target === modalBackdrop) closeModal(); });
  window.addEventListener("keydown", (e) => { if(e.key === "Escape") closeModal(); });
}
function openModal(entry){
  if(!modalBackdrop) return;
  modalBackdrop.classList.add("active");
  modalBackdrop.setAttribute("aria-hidden","false");
  modalPhoto.src = entry.photo;
  modalName.textContent = entry.name;
  modalRole.textContent = entry.role;
  modalBio.textContent = entry.bio;
  modalStatus.textContent = entry.status === "online" ? "Online" : entry.status === "alert" ? "Alert" : "Offline";
  modalStatus.className = `status-badge status-${entry.status}`;
  modalLocation.textContent = entry.location;
  modalHours.textContent = `${entry.hours}ч на мисия`;
}
function closeModal(){
  modalBackdrop?.classList.remove("active");
  modalBackdrop?.setAttribute("aria-hidden","true");
}

// Tilt ефект
function initTilt(){
  const cards = document.querySelectorAll(".tilt");
  cards.forEach(card => {
    card.addEventListener("mousemove", (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left, y = e.clientY - rect.top;
      const rx = ((y / rect.height) - 0.5) * -4;
      const ry = ((x / rect.width) - 0.5) * 6;
      card.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg) translateY(-4px)`;
    });
    card.addEventListener("mouseleave", () => {
      card.style.transform = "";
    });
  });
}

// Reveal при скрол
function initReveal(){
  const items = document.querySelectorAll(".reveal");
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add("visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.35 });
  items.forEach(el => obs.observe(el));
}

// Клавиатурен shortcut за търсене
function initShortcuts(){
  const search = document.getElementById("crewSearch");
  window.addEventListener("keydown", (e) => {
    if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k"){
      e.preventDefault(); search?.focus();
    }
  });
}
