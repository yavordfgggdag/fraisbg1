
/* ---------------------------
   Утилити: безопасен query
   --------------------------- */
const $ = (sel, ctx=document) => ctx.querySelector(sel);
const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));

/* ---------------------------
   Инициализация при load
   --------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  initProgressBars();
  initLEDs();
  initRadar();
  initOrbitParticles();
  initTooltips();
  initModals();
  initTelemetrySimulation();
  initSparklinePlaceholders();
  bindUIActions();
  // light initial toast
  showToast("Система заредена — визуализация активна", 3000);
});

/* ===========================
   PROGRESS BARS (animated)
   =========================== */
function initProgressBars(){
  const bars = $$('.bar[data-value]');
  bars.forEach(bar => {
    const value = Number(bar.getAttribute('data-value')) || 0;
    // Place inner element if not added
    if (!bar.querySelector('i')){
      const inner = document.createElement('i');
      inner.style.width = '0%';
      bar.appendChild(inner);
    }
    // staggered animation
    setTimeout(() => {
      bar.querySelector('i').style.width = value + '%';
      if (value < 30) bar.classList.add('low');
      if (value < 15) bar.parentElement.classList.add('critical');
    }, 200 + Math.random()*900);
  });
}

/* ===========================
   LED SIMULATION
   =========================== */
function initLEDs(){
  const leds = $$('.led');
  // simple blink loop
  setInterval(() => {
    leds.forEach((l, i) => {
      // vary behavior based on index for visual variety
      const chance = 0.6 + Math.sin(Date.now()/1000 + i)/6;
      l.style.opacity = Math.random() > chance ? '1' : '0.3';
      // micro bounce
      l.style.transform = Math.random() > 0.95 ? 'scale(1.35)' : 'scale(1)';
    });
  }, 700);
}

/* ===========================
   RADAR (canvas, sweep + blips)
   =========================== */
function initRadar(){
  const wraps = $$('.radar-wrap');
  wraps.forEach(wrap => {
    const canvas = document.createElement('canvas');
    canvas.className = 'radar-canvas';
    wrap.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    // sizing
    function resize(){
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.floor(rect.width * devicePixelRatio);
      canvas.height = Math.floor(rect.height * devicePixelRatio);
      ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
      drawFrame();
    }
    window.addEventListener('resize', resize);
    resize();

    // radar state
    let angle = 0;
    const blips = [];
    for (let i=0;i<8;i++){
      blips.push({
        r: Math.random()*0.45 + 0.12, // radius fraction
        theta: Math.random()*Math.PI*2,
        size: 2 + Math.random()*6,
        life: 1,
        pulse: Math.random()*2
      });
    }

    // draw loop
    function drawFrame(){
      const w = canvas.width / devicePixelRatio;
      const h = canvas.height / devicePixelRatio;
      ctx.clearRect(0,0,w,h);

      // background radial vignette
      const g = ctx.createRadialGradient(w*0.6,h*0.4,Math.min(w,h)*0.05,w*0.5,h*0.5,Math.max(w,h)*0.9);
      g.addColorStop(0,'rgba(110,242,255,0.02)');
      g.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0,0,w,h);

      // center point
      const cx = w/2, cy = h/2;
      const radius = Math.min(w,h) * 0.44;

      // grid rings
      ctx.save();
      ctx.translate(cx,cy);
      ctx.strokeStyle = 'rgba(255,255,255,0.03)';
      ctx.lineWidth = 1;
      for (let r=1; r<=4; r++){
        ctx.beginPath(); ctx.arc(0,0, radius*(r/4), 0, Math.PI*2); ctx.stroke();
      }
      // cross lines
      ctx.beginPath(); ctx.moveTo(-radius,0); ctx.lineTo(radius,0); ctx.moveTo(0,-radius); ctx.lineTo(0,radius); ctx.stroke();
      ctx.restore();

      // draw blips (fading)
      blips.forEach(b => {
        // update
        b.theta += 0.005 * (0.8 + Math.sin(Date.now()/10000));
        b.pulse = 0.9 + Math.sin(Date.now()/400 + b.life*10)*0.1;
        // position
        const x = cx + Math.cos(b.theta) * radius * b.r;
        const y = cy + Math.sin(b.theta) * radius * b.r;
        ctx.beginPath();
        const alpha = 0.6 * (0.7 + Math.sin(Date.now()/1000 + b.life*10)*0.3);
        ctx.fillStyle = `rgba(155,89,255,${alpha})`;
        ctx.shadowColor = 'rgba(155,89,255,0.35)';
        ctx.shadowBlur = 8;
        ctx.arc(x,y,b.size*b.pulse,0,Math.PI*2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // sweeping beam
      angle += 0.01;
      ctx.save();
      ctx.translate(cx,cy);
      const grd = ctx.createLinearGradient(0,0, Math.cos(angle)*radius, Math.sin(angle)*radius);
      grd.addColorStop(0,'rgba(110,242,255,0.0)');
      grd.addColorStop(0.8,'rgba(110,242,255,0.05)');
      grd.addColorStop(1,'rgba(110,242,255,0.12)');
      ctx.rotate(angle);
      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.arc(0,0, radius, -0.03, 0.03);
      ctx.closePath();
      ctx.fillStyle = grd;
      ctx.fill();
      ctx.restore();

      // animated central halo
      ctx.beginPath();
      const haloGradient = ctx.createRadialGradient(cx,cy,0,cx,cy,radius*0.7);
      haloGradient.addColorStop(0,'rgba(155,89,255,0.04)');
      haloGradient.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle = haloGradient;
      ctx.fillRect(0,0,w,h);

      // schedule next frame
      requestAnimationFrame(drawFrame);
    }
    drawFrame();
  });
}

/* ===========================
   ORBIT PARTICLES (decor)
   =========================== */
function initOrbitParticles(){
  const wraps = $$('.orbit-wrap');
  wraps.forEach(wrap => {
    // create some particles
    const count = 8;
    const particles = [];
    for (let i=0;i<count;i++){
      const el = document.createElement('div');
      el.className = 'orbit-particle';
      wrap.appendChild(el);
      particles.push({el, a: Math.random()*Math.PI*2, r: 40 + Math.random()*140, speed: (0.3 + Math.random()*0.8) * (Math.random()>0.5?1:-1), size: 4 + Math.random()*6});
      el.style.width = el.style.height = particles[i].size + 'px';
    }
    // animate
    let last = performance.now();
    function frame(t){
      const dt = (t - last)/1000; last = t;
      const rect = wrap.getBoundingClientRect();
      const cx = rect.width/2, cy = rect.height/2;
      particles.forEach(p => {
        p.a += p.speed * dt;
        const x = cx + Math.cos(p.a) * p.r;
        const y = cy + Math.sin(p.a) * p.r * 0.6;
        p.el.style.transform = `translate(${x}px, ${y}px) translate(-50%,-50%)`;
      });
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  });
}

/* ===========================
   TOOLTIP system (simple)
   =========================== */
function initTooltips(){
  const targets = $$('[data-tooltip]');
  let tip = null;
  targets.forEach(t => {
    t.addEventListener('mouseenter', (e) => {
      if (!tip){
        tip = document.createElement('div'); tip.className = 'tooltip';
        document.body.appendChild(tip);
      }
      tip.textContent = t.getAttribute('data-tooltip');
      tip.style.opacity = 1;
      positionTooltip(tip, e.target);
    });
    t.addEventListener('mousemove', (e) => {
      if (tip) positionTooltip(tip, e.target);
    });
    t.addEventListener('mouseleave', () => {
      if (tip) tip.style.opacity = 0;
    });
  });

  function positionTooltip(el, target){
    const r = target.getBoundingClientRect();
    el.style.left = (window.scrollX + r.left + r.width/2) + 'px';
    el.style.top = (window.scrollY + r.top - 12) + 'px';
    el.style.transform = 'translate(-50%,-110%)';
  }
}

/* ===========================
   MODAL (basic)
   =========================== */
function initModals(){
  // create a single reusable modal container
  let backdrop = document.querySelector('.modal-backdrop');
  if (!backdrop){
    backdrop = document.createElement('div'); backdrop.className = 'modal-backdrop';
    backdrop.innerHTML = `<div class="modal" role="dialog" aria-modal="true">
      <div class="header"><div class="title glitch" data-text="Панел" aria-hidden="true">Панел</div><div class="close btn-ghost">Затвори</div></div>
      <div class="content" style="margin-top:12px"></div>
    </div>`;
    document.body.appendChild(backdrop);
  }
  const modal = backdrop.querySelector('.modal');
  const content = backdrop.querySelector('.content');
  const closeBtn = backdrop.querySelector('.close');
  closeBtn.addEventListener('click', hideModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) hideModal(); });

  // expose API
  window.showModal = (title, html) => {
    modal.querySelector('.title').textContent = title || 'Панел';
    content.innerHTML = html || '';
    backdrop.style.display = 'flex';
    setTimeout(()=> backdrop.style.opacity = 1, 10);
  };
  window.hideModal = () => {
    backdrop.style.opacity = 0;
    setTimeout(()=> backdrop.style.display = 'none', 220);
  };
}

/* ===========================
   TOAST helper
   =========================== */
function showToast(text, ms=2000){
  let t = document.querySelector('.toast');
  if (!t){
    t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t);
  }
  t.textContent = text;
  t.style.display = 'block';
  t.style.opacity = 1;
  setTimeout(()=> {
    t.style.opacity = 0;
    setTimeout(()=> t.style.display = 'none', 500);
  }, ms);
}

/* ===========================
   TELEMETRY SIM (randomized, but smooth)
   =========================== */
function initTelemetrySimulation(){
  // find elements by data-telemetry attributes
  const telemetry = $$('[data-telemetry]');
  if (!telemetry.length) return;

  // internal state
  const state = {};
  telemetry.forEach(el => {
    const key = el.getAttribute('data-telemetry');
    // initial value: parse numeric from content or attr
    const initial = Number(el.textContent.match(/-?\d+(\.\d+)?/)?.[0]) || Number(el.getAttribute('data-value')) || 0;
    state[key] = initial;
  });

  // update loop: smooth lerp to new random target
  setInterval(() => {
    Object.keys(state).forEach(k => {
      const target = state[k] + (Math.random()-0.5) * (k.includes('temp')?0.6: (k.includes('rad')?0.02: (k.includes('oxygen')?1.2: (Math.random()*4-2))));
      state[k] = lerp(state[k], target, 0.14);
      // write back to dom elements matching key
      telemetry.forEach(el => {
        if (el.getAttribute('data-telemetry') === k){
          // format: if it's temp show °C, if rad show μSv, else show 2 decimals
          if (k.includes('temp')) el.textContent = state[k].toFixed(1) + ' °C';
          else if (k.includes('pressure')) el.textContent = state[k].toFixed(2) + ' atm';
          else if (k.includes('rad')) el.textContent = state[k].toFixed(3) + ' μSv/h';
          else el.textContent = (Math.round(state[k*1*1])) || state[k].toFixed(0);
        }
      });
    });
  }, 900);

  function lerp(a,b,t){return a + (b-a)*t;}
}

/* ===========================
   Sparkline placeholders (canvas mini-charts)
   =========================== */
function initSparklinePlaceholders(){
  const holders = $$('.sparkline');
  holders.forEach(h => {
    const canvas = document.createElement('canvas');
    h.appendChild(canvas);
    canvas.style.width = '100%'; canvas.style.height = '48px';
    const ctx = canvas.getContext('2d');

    // create initial data
    const data = Array.from({length:40}, ()=> 30 + Math.random()*60);
    // resize function
    function resize(){
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.floor(rect.width * devicePixelRatio);
      canvas.height = Math.floor(rect.height * devicePixelRatio);
      ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
      draw();
    }
    window.addEventListener('resize', resize);
    resize();

    function draw(){
      const w = canvas.width / devicePixelRatio;
      const h = canvas.height / devicePixelRatio;
      ctx.clearRect(0,0,w,h);

      // gradient fill
      const g = ctx.createLinearGradient(0,0,0,h);
      g.addColorStop(0,'rgba(155,89,255,0.15)');
      g.addColorStop(1,'rgba(110,242,255,0.03)');

      // path
      ctx.beginPath();
      const step = w / (data.length-1);
      data.forEach((v,i) => {
        const x = i*step;
        const y = h - ( (v / 120) * h );
        if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
      });
      ctx.strokeStyle = 'rgba(155,89,255,0.9)'; ctx.lineWidth=2; ctx.stroke();

      // fill under
      ctx.lineTo(w,h); ctx.lineTo(0,h); ctx.closePath();
      ctx.fillStyle = g; ctx.fill();
    }

    // animate update
    setInterval(()=> {
      data.shift(); data.push(30 + Math.random()*80);
      draw();
    }, 700);
  });
}

/* ===========================
   UI bindings
   =========================== */
function bindUIActions(){
  // show modal demo on any .btn that has data-modal attr
  $$('a[data-modal], button[data-modal]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const t = el.getAttribute('data-modal-title') || 'Детайли';
      const html = `<p class="small">Това е визуален модал за демонстрация. Можете да показвате детайлна информация, графики или логове тук.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px">
          <div class="panel"><div class="small">Кратък статус</div><div style="font-weight:800;color:var(--accent-1);margin-top:8px">OK</div></div>
          <div class="panel"><div class="small">Последни логове</div><div style="margin-top:8px" class="small">12 събития</div></div>
        </div>`;
      showModal(t, html);
    });
  });

  // sample "diagnostics" buttons produce toast & modal
  $$('a.btn').forEach(b => {
    b.addEventListener('click', (e) => {
      // allow navigation if normal link without href '#' - but intercept if data-action
      const action = b.getAttribute('data-action');
      if (action === 'simulate'){
        e.preventDefault();
        showToast('Симулираме маневра...', 2200);
        setTimeout(()=> showModal('Симулация завършена', '<p class="small">Корекцията е представена само визуално.</p>'), 1200);
      }
    });
  });

  // example: show crew member modal on avatar click
  $$('.crew-avatar').forEach(av => {
    av.addEventListener('click', (e) => {
      const name = av.nextElementSibling?.textContent || 'Член';
      showModal(name, `<p class="small">Детайли за ${name}. Тук можете да добавите снимки и биография.</p>`);
    });
  });

  // keyboard escape to close modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && window.hideModal) hideModal();
  });
}

/* ===========================
   Small helpers & dev utils
   =========================== */
function $(sel, ctx=document){ return ctx.querySelector(sel); }
function $$(sel, ctx=document){ return Array.from(ctx.querySelectorAll(sel)); }

/* ===========================
   Optional: expose debug functions to console
   =========================== */
window.__panelDebug = {
  showToast,
  showModal,
  hideModal
};
