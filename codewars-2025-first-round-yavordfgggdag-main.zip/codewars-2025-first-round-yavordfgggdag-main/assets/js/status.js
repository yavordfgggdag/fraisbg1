<script>
// Основни елементи
const energyBar = document.getElementById('energyBar');
const oxygenBar = document.getElementById('oxygenBar');
const energyText = document.getElementById('energyText');
const oxygenText = document.getElementById('oxygenText');
const statusValue = document.getElementById('statusValue');
const syncTime = document.getElementById('syncTime');
const speedRange = document.getElementById('speedRange');
const missionFill = document.getElementById('missionFill');
const panel = document.querySelector('.panel-wrap');
const stopBtn = document.getElementById('stopShip');

let energy = 68;
let oxygen = 36;
let missionProgress = 0;
let shipStopped = false;


function setBar(barEl, percent, textEl){
  percent = Math.max(0, Math.min(100, Math.round(percent)));
  barEl.style.width = percent + '%';
  if(textEl) textEl.textContent = percent + '%';
  if(percent <= 20){
    barEl.classList.add('critical');
    audioAlarm.play().catch(()=>{});
  } else{
    barEl.classList.remove('critical');
  }
}

function updateSync(){
  const d = new Date();
  syncTime.textContent = d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
}

function pulse(el){
  el.animate([
    { boxShadow: '0 6px 18px rgba(78,192,106,0.12)', transform: 'scaleX(1)'},
    { boxShadow: '0 12px 34px rgba(78,192,106,0.18)', transform: 'scaleX(1.02)'},
    { boxShadow: '0 6px 18px rgba(78,192,106,0.12)', transform: 'scaleX(1)'}
  ], { duration: 420, easing:'ease-out' });
}

function checkCritical() {
  if(energy < 10 || oxygen < 10){
    panel.classList.add('critical');
    statusValue.textContent = '!!! АВАРИЯ';
    statusValue.style.color = '#ff0000';
  } else {
    panel.classList.remove('critical');
    statusValue.style.color = shipStopped ? '#c7cbd1' : '#4ec06a';
    statusValue.textContent = shipStopped ? 'Пусни кораба' : 'Активна';
  }
}

// Инициализация
setBar(energyBar, energy, energyText);
setBar(oxygenBar, oxygen, oxygenText);
updateSync();
checkCritical();

// Превключване на статус кораба
stopBtn.addEventListener('click', ()=>{
  shipStopped = !shipStopped;
  stopBtn.textContent = shipStopped ? 'Пусни кораба' : 'Спря кораба';
  checkCritical();
  updateSync();
});

// Refill бутони с искри
document.getElementById('refillEnergy').addEventListener('click', ()=>{
  energy = Math.min(100, energy + 12);
  setBar(energyBar, energy, energyText);
  pulse(energyBar);
  createSparks(energyBar, '#4ec06a');
  updateSync();
  audioRefill.play().catch(()=>{});
  checkCritical();
});
document.getElementById('refillOxy').addEventListener('click', ()=>{
  oxygen = Math.min(100, oxygen + 18);
  setBar(oxygenBar, oxygen, oxygenText);
  pulse(oxygenBar);
  createSparks(oxygenBar, '#2fb86a');
  updateSync();
  audioRefill.play().catch(()=>{});
  checkCritical();
});

// Автоматична консумация на системи
setInterval(()=>{
  if(!shipStopped){
    oxygen = Math.max(0, oxygen - (Math.random()*2.8));
    energy = Math.max(0, energy - (Math.random()*0.6));
    missionProgress = Math.min(100, missionProgress + 0.12);
    missionFill.style.width = missionProgress + '%';
  }
  setBar(oxygenBar, oxygen, oxygenText);
  setBar(energyBar, energy, energyText);
  checkCritical();
}, 2400);

// Настройка на скорост
speedRange.addEventListener('input', ()=>{
  const v = Number(speedRange.value);
  const mapped = Math.max(250, Math.min(1200, Math.round((v/1500)*1200)));
  document.querySelectorAll('.bar-fill').forEach(b=>b.style.transitionDuration = mapped + 'ms');
});

// Функция за искри
function createSparks(el, color){
  for(let i=0;i<8;i++){
    const spark = document.createElement('div');
    spark.style.position='absolute';
    spark.style.width='4px'; spark.style.height='4px';
    spark.style.background=color; spark.style.borderRadius='50%';
    spark.style.left=Math.random()*el.offsetWidth+'px';
    spark.style.top='50%';
    spark.style.pointerEvents='none';
    spark.style.opacity=1;
    spark.style.transform='translateY(-50%)';
    el.appendChild(spark);
    const anim = spark.animate([
      {transform:'translateY(-50%) translateX(0) scale(1)', opacity:1},
      {transform:'translateY(-150%) translateX('+(Math.random()*40-20)+'px) scale(0)', opacity:0}
    ],{duration:600+Math.random()*300, easing:'ease-out'});
    anim.onfinish=()=>spark.remove();
  }
}
</script>
