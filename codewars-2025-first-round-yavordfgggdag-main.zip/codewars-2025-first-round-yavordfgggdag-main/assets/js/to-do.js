const form = document.getElementById('todo-form');
const input = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');
const filterButtons = document.querySelectorAll('.filter-btn');
const clearCompletedBtn = document.getElementById('clear-completed');
const counter = document.getElementById('counter');

let todos = [];

function renderTodos(filter = 'all') {
  todoList.innerHTML = '';
  let filtered = todos;
  if(filter === 'active') filtered = todos.filter(t => !t.completed);
  if(filter === 'completed') filtered = todos.filter(t => t.completed);

  filtered.forEach((todo, index) => {
    const li = document.createElement('li');
    li.className = todo.completed ? 'completed' : '';
    
    const span = document.createElement('span');
    span.textContent = todo.text;
    span.className = 'todo-text';
    span.addEventListener('click', () => {
      todos[index].completed = !todos[index].completed;
      renderTodos(getActiveFilter());
    });

    const removeBtn = document.createElement('button');
    removeBtn.textContent = '✖';
    removeBtn.className = 'remove-btn';
    removeBtn.addEventListener('click', () => {
      todos.splice(index, 1);
      renderTodos(getActiveFilter());
    });

    li.appendChild(span);
    li.appendChild(removeBtn);
    todoList.appendChild(li);
  });

  counter.textContent = `Общо задачи: ${todos.length}, Активни: ${todos.filter(t => !t.completed).length}`;
}

function getActiveFilter() {
  return document.querySelector('.filter-btn.active').dataset.filter;
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if(text === '') return;
  todos.push({ text, completed: false });
  input.value = '';
  renderTodos(getActiveFilter());
});

filterButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    filterButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderTodos(btn.dataset.filter);
  });
});

clearCompletedBtn.addEventListener('click', () => {
  todos = todos.filter(t => !t.completed);
  renderTodos(getActiveFilter());
});

renderTodos();
