const canvas = document.getElementById('radar');
const ctx = canvas.getContext('2d');

let ship = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  angle: 0,
  speed: 0
};

function drawRadar() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Grid
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  for (let i = 0; i < canvas.width; i += 50) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, canvas.height);
    ctx.stroke();
  }
  for (let i = 0; i < canvas.height; i += 50) {
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(canvas.width, i);
    ctx.stroke();
  }

  // Ship
  ctx.save();
  ctx.translate(ship.x, ship.y);
  ctx.rotate(ship.angle);
  ctx.beginPath();
  ctx.moveTo(14, 0);
  ctx.lineTo(-10, -8);
  ctx.lineTo(-10, 8);
  ctx.closePath();
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = '#9b59ff';
  ctx.shadowBlur = 12;
  ctx.fill();
  ctx.restore();
}

function update() {
  ship.x += Math.cos(ship.angle) * ship.speed;
  ship.y += Math.sin(ship.angle) * ship.speed;

  // wrap around
  if (ship.x < 0) ship.x = canvas.width;
  if (ship.x > canvas.width) ship.x = 0;
  if (ship.y < 0) ship.y = canvas.height;
  if (ship.y > canvas.height) ship.y = 0;

  document.getElementById('speed').textContent = ship.speed.toFixed(1);
  document.getElementById('course').textContent =
    ((ship.angle * 180 / Math.PI) + 360) % 360 | 0;

  drawRadar();
  requestAnimationFrame(update);
}

/* Controls */
function accelerate() { ship.speed = Math.min(ship.speed + 0.2, 6); }
function brake() { ship.speed = Math.max(ship.speed - 0.3, 0); }
function turnLeft() { ship.angle -= 0.1; }
function turnRight() { ship.angle += 0.1; }
function resetShip() {
  ship.x = canvas.width / 2;
  ship.y = canvas.height / 2;
  ship.angle = 0;
  ship.speed = 0;
}

update();
